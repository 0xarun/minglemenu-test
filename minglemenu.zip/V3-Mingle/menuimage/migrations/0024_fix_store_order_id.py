from django.db import migrations, models

def set_store_order_id(apps, schema_editor):
    Order = apps.get_model('menuimage', 'Order')
    Store = apps.get_model('menuimage', 'Store')

    for store in Store.objects.all():
        orders = Order.objects.filter(store=store).order_by('id')
        for index, order in enumerate(orders, start=1):
            order.store_order_id = index
            order.save()

class Migration(migrations.Migration):

    dependencies = [
        ('menuimage', '0020_order_store_order_id_alter_order_unique_together'),
    ]

    operations = [
        migrations.RunPython(set_store_order_id),
        migrations.AlterField(
            model_name='order',
            name='store_order_id',
            field=models.PositiveIntegerField(default=1),
        ),
    ]