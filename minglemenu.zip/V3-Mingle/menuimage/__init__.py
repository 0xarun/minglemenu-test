from .custom_filters import *  # Ensure this line is added to register the custom filter
