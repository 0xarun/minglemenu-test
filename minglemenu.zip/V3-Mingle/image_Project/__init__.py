default_app_config = 'menuimage.apps.MenuimageConfig'
